package repository;

public interface ExibirInterface {
    void exibir(Boolean cr);
    //Se quiser colocar o código aqui, coloque default entre "public" e "void".
}
